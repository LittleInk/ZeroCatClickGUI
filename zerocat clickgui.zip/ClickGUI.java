package i.zerocat.gui.ui;

import i.zerocat.Client;
import i.zerocat.font.CFontRenderer;
import i.zerocat.font.FontLoaders;
import i.zerocat.gui.ui.category.CategoryUI;
import i.zerocat.gui.ui.category.ModuleUI;
import i.zerocat.module.Category;
import i.zerocat.module.Module;
import i.zerocat.utils.misc.TimerUtils;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.util.EnumChatFormatting;
import org.lwjgl.Sys;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.util.ArrayList;

public class ClickGUI extends GuiScreen {
    static ArrayList<CategoryUI> categoryUIs = new ArrayList<CategoryUI>();
    int movex, movey;

    static {
        int y = 50;
        categoryUIs.add(new CategoryUI(20, y + 20, "Combat", Category.combat));
        categoryUIs.add(new CategoryUI(20, y + 45, "Movement", Category.move));
        categoryUIs.add(new CategoryUI(20, y + 70, "Visual", Category.visual));
        categoryUIs.add(new CategoryUI(20, y + 95, "World", Category.world));
        categoryUIs.add(new CategoryUI(20, y + 120, "Settings", Category.settings));
        for (CategoryUI c : categoryUIs) {
            //  if (c.hold) {
            //System.out.println(state);
            //  if (state == 0)
            c.hold = false;
            // }
        }
    }

    public ClickGUI() {

    }
    @Override
    public void onGuiClosed(){

    }
    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        CFontRenderer font = FontLoaders.default20;
        font.drawStringWithShadow((Client.instance.isDev ? EnumChatFormatting.RED + "Development" : EnumChatFormatting.GREEN + "User") + EnumChatFormatting.WHITE + ":" + Client.instance.user, 0, this.height - font.getHeight() - 2, -1);
        for (CategoryUI c : categoryUIs) {
            c.draw();
        }
    }

    @Override
    public void keyTyped(char typedChar, int keyCode) {
        if (keyCode == 1) {
            this.mc.displayGuiScreen((GuiScreen) null);
            if (this.mc.currentScreen == null) {
                this.mc.setIngameFocus();
            }
        }
        for (CategoryUI c : categoryUIs) {
            for (ModuleUI m : c.uis) {
                if (m.change){
                    Module m1 = Client.moduleManager.getModuleByName(m.name);
                    m.change = false;
                    if (keyCode == 28){
                        m1.setKey(0);
                        return;
                    }
                    m1.setKey(keyCode);
                    m.key = true;
                    m.keyname = "Input Key:"+ Keyboard.getKeyName(keyCode) + ".";
                   // m.draw();
                   // TimerUtils timer = new TimerUtils();
                  /*  while (timer.delay(500))
                        m.key = false;
                        timer.reset();
                    }*/

                }
            }
        }
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {

        for (CategoryUI c : categoryUIs) {
            if (mouseX > c.x && mouseX < (c.x + c.width)) {
                if (mouseY > c.y && mouseY < (c.y + c.high)) {
                    if (mouseButton == 0) {
                        movex = mouseX - c.x;
                        movey = mouseY - c.y;
                        c.hold = true;
                    } else if (mouseButton == 1) {
                        c.state = !c.state;
                    }
                }
            }
        }
        for (CategoryUI c : categoryUIs) {
            if (!c.state)
                return;
            for (ModuleUI m : c.uis) {
                if (m.key)
                    m.key = false;
                if (mouseX > m.x && mouseX < (m.x + m.width)) {
                    if (mouseY > m.y && mouseY < (m.y + m.high)) {
                        if (mouseButton == 1) {
                            Module m1 = Client.moduleManager.getModuleByName(m.name);
                            if (!m1.getValues().isEmpty()) {
                                m.state = true;
                                m.drawSettings();
                            }
                        } else if (mouseButton == 0) {
                            Module m1 = Client.moduleManager.getModuleByName(m.name);
                            m1.toggle();
                        } else if (mouseButton == 2) {
                            m.change = true;
                        }
                    }
                }
            }
        }
    }

    @Override
    public void mouseClickMove(int mouseX, int mouseY, int clickedMouseButton, long timeSinceLastClick) {
        for (CategoryUI c : categoryUIs) {
            if (c.hold) {
                c.x = mouseX - movex;
                c.y = mouseY - movey;
                c.draw();
            }
        }
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int state) {
        for (CategoryUI c : categoryUIs) {
          //  if (c.hold) {
                //System.out.println(state);
              //  if (state == 0)
                    c.hold = false;
           // }
        }
    }
}
