package i.zerocat.gui.ui.category;

import i.zerocat.Client;
import i.zerocat.font.CFontRenderer;
import i.zerocat.font.FontLoaders;
import i.zerocat.gui.ui.SetUI;
import i.zerocat.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;

import java.awt.*;

public class ModuleUI {
    public int x,y;
    public final int width = 75,high = 20;
    public boolean ishover;
    public String name;
    public boolean state;
    public boolean change;
    public boolean key;
    public String keyname;

    public ModuleUI(int x1,int y1,String name){
        this.name = name;
        this.x = x1;
        this.y = y1;
    }

    //combat move visual world settings
    public void draw(){
        Module m = Client.moduleManager.getModuleByName(name);
        this.state = m.state;
        int color = new Color(38,31,37,150).getRGB();
        int color_text = state?new Color(255,255,255
        ).getRGB():new Color(192,192,192 ).getRGB();
        CFontRenderer font = FontLoaders.default18;
        Gui.drawRect(x,y,x + width,y + high,color);
        font.drawCenteredString(key?keyname:(change?"Press keyboard.":name),x + (width / 2),y + 6,color_text);
    }

    public void drawSettings() {
        Module m = Client.moduleManager.getModuleByName(name);
        Minecraft.getMinecraft().displayGuiScreen(new SetUI(m.getValues(),this));
    }
}
