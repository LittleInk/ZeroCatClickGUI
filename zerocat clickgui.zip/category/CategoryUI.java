package i.zerocat.gui.ui.category;

import i.zerocat.Client;
import i.zerocat.font.CFontRenderer;
import i.zerocat.font.FontLoaders;
import i.zerocat.manager.ModuleManager;
import i.zerocat.module.Category;
import i.zerocat.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class CategoryUI {
    public int x,y;
    public final int width = 75,high = 20;
    String name;
    public boolean hold;
    public boolean state;
    public Category c;
    public List<Module> mods;
    public List<ModuleUI> uis;
    static {

    }
    public CategoryUI(int x1, int y1, String name, Category c){
        this.name = name;
        this.x = x1;
        this.y = y1;
        this.c = c;
        mods = new ArrayList<>();
        uis = new ArrayList<>();
        for(Module m: Client.moduleManager.getModules(c)){
            mods.add(m);
        }
        int y2 = y + high;
        for (Module m:mods){
            uis.add(new ModuleUI(x,y2,m.name));
            y2 += high;
        }
    }

    //combat move visual world settings
    public void draw(){
        //192,192,192
        int color = new Color(38,31,37).getRGB();
        int color_text = new Color(255,255,255).getRGB();
        CFontRenderer font = FontLoaders.default20;
        Gui.drawRect(x,y,x + width,y + high,color);
        font.drawCenteredString(name,x + (width / 2),y + 6,color_text);
        int y1 = y + high;
        //ModuleUI
        if (this.state){
            for(ModuleUI m:uis){
                m.x = this.x;
                m.y = y1;
                m.draw();
                y1 +=high;
            }
        }
    }

}
