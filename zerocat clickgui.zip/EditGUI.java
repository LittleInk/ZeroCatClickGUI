package i.zerocat.gui.ui;

import com.mojang.realmsclient.gui.ChatFormatting;
import i.zerocat.Client;
import i.zerocat.font.CFontRenderer;
import i.zerocat.font.FontLoaders;
import i.zerocat.gui.ui.category.CategoryUI;
import i.zerocat.gui.ui.category.ModuleUI;
import i.zerocat.module.Module;
import i.zerocat.module.visual.GuiRender;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.util.EnumChatFormatting;

import java.awt.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Objects;

public class EditGUI extends GuiScreen {
    static CategoryUI c;
    static{
        c = new CategoryUI(50 ,50,"ArrayList",null);
    }
    int movex, movey;
    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        c.draw();
        CFontRenderer font = FontLoaders.default20;
        font.drawStringWithShadow((Client.instance.isDev ? EnumChatFormatting.RED + "Development" : EnumChatFormatting.GREEN + "User") + EnumChatFormatting.WHITE + ":" + Client.instance.user, 0, this.height - font.getHeight() - 2, -1);
        Client.moduleManager.getModule(GuiRender.class).x = c.x + 75;
        Client.moduleManager.getModule(GuiRender.class).y = c.y + 21;
    }
    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        if (mouseX > c.x && mouseX < (c.x + c.width)) {
            if (mouseY > c.y && mouseY < (c.y + c.high)) {
                if (mouseButton == 0) {
                    movex = mouseX - c.x;
                    movey = mouseY - c.y;
                    c.hold = true;
                } else if (mouseButton == 1) {
                    c.state = !c.state;
                    Client.moduleManager.getModule(GuiRender.class).cansee = c.state;
                    Client.moduleManager.getModule(GuiRender.class).edit = true;
                    if (c.state){
                        Client.moduleManager.getModule(GuiRender.class).drawArrayList();
                    }
                }
            }
        }
    }
    @Override
    public void onGuiClosed(){
        Client.moduleManager.getModule(GuiRender.class).edit = false;
    }
    @Override
    public void mouseClickMove(int mouseX, int mouseY, int clickedMouseButton, long timeSinceLastClick) {
        if (c.hold) {
            c.x = mouseX - movex;
            c.y = mouseY - movey;
            c.draw();
            Client.moduleManager.getModule(GuiRender.class).x = c.x + 75;
            Client.moduleManager.getModule(GuiRender.class).y = c.y + 21;
        }
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int state) {
        if (c.hold) {
            if (state == 0)
                c.hold = false;
        }
    }
}
