package i.zerocat.gui.ui.setuis;

import i.zerocat.font.CFontRenderer;
import i.zerocat.font.FontLoaders;
import net.minecraft.client.gui.Gui;

import java.awt.*;

public class BooleanUI {
    public boolean value;
    public String name;
    public int[] checkx = {},checky = {};

    public BooleanUI(String name,boolean value){
        this.name = name;
        this.value = value;
    }
    public void draw(int x,int y){
        int lastx = x + 190;
        CFontRenderer font = FontLoaders.default18;
        font.drawStringWithShadow(name,x,y,-1);
        Gui.drawRect(lastx - font.getHeight(),y, lastx,y + font.getHeight(),this.value?-1:new Color(192,192,192).getRGB());
        checkx = new int[]{lastx - font.getHeight(), lastx};
        checky = new int[]{y,y + font.getHeight()};
    }

}
