package i.zerocat.gui.ui.setuis;

import i.zerocat.font.CFontRenderer;
import i.zerocat.font.FontLoaders;
import net.minecraft.client.gui.Gui;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class PushUI{
    float min,max,value,inc;
    public int[] checkx,checky;
    public int[] canmove = new int[]{};
    public int m1,m2;
    public String name;
    int lastx;
    public boolean hold;
    public PushUI(String name,float min,float max,float value){
        this.name = name;
        this.min = min;
        this.max = max;
        this.value = value;
    }
    public void setValue(float f){
        this.value = f;
    }
    public void drawmove(){

        mathValue();
        FontLoaders.default16.drawStringWithShadow("" + mathValue(),lastx - 105,y,-1);
        Gui.drawRect(lastx - 80 ,y,m1,y + 5, new Color(255,255,255,180).getRGB());
        Gui.drawRect(m1,y - 2,m2,y + 7,-1);
        checkx = new int[]{
                m1,m2
        };
        checky = new int[]{
                y - 2,y + 7
        };
    }
    int x;
    int y ;
    public void draw(float xs, float ys){

        lastx = (int)xs + 190;
        x = (int) xs;
        y = (int) ys;
        if(m1 == 0){
            m1 = (int)(lastx - 80 + get(value)) - 4;
            m2 = (int)(lastx - 80 + get(value)) + 4;
        }

        CFontRenderer font = FontLoaders.default18;
        font.drawStringWithShadow( name + "("+min+"~"+max+")",x,y,-1);
        Gui.drawRect(lastx - 80,y,lastx,y + 5,new Color(192,192,192,210).getRGB());
        drawmove();
        canmove = new int[]{
                lastx - 80,lastx
        };

    }
    public float mathValue(){
        float a = m1 + 5 - (lastx - 80);
        if (a == 0)
            return 0.0f;
        this.value = (float) ((a / 80.0) * max);
        if (value > max)
            value = max;
        return value;
    }
    public int get(float value){
        if (value > max)
            value = max;
        return (int) ((value / max) * 80.0f);
    }
}
