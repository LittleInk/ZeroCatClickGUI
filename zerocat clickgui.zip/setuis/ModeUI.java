package i.zerocat.gui.ui.setuis;

import i.zerocat.font.CFontRenderer;
import i.zerocat.font.FontLoaders;
import net.minecraft.client.gui.Gui;

import java.awt.*;

public class ModeUI {
    public String[] modes = new String[]{};
    public String name;
    public String value;
    public int[] check;
    public ModeUI(String name,String[] modes,String value){
        this.name = name;
        this.modes = modes;
        this.value = value;
    }
    int x,y;
    CFontRenderer font = FontLoaders.default18;
    public void draw(int x,int y){
        this.x = x;
        this.y = y;
        font.drawStringWithShadow(name,x,y,-1);
        this.drawMode();
    }
    public void drawMode(){
        int lastx = x + 190;
        int width = 40;
        Gui.drawRect(lastx - 50,y - 2,lastx,y + font.getHeight() + 1,new Color(99, 97, 97).getRGB());
        font.drawCenteredString(value, (lastx - 45) + (width / 2),y + 1,-1);
        check = new int[]{
                lastx - 50,
                lastx,
                y - 2,
                y + font.getHeight() + 1
        };
    }
    public String click(){
        int length = modes.length;
        if (modes[length - 1].equalsIgnoreCase(value)){
            value = modes[0];
            return value;
        }
        for(int i = 0;i < length;i++){
            if (modes[i] == value){
                value = modes[i + 1];
                break;
            }
        }
        return value;
    }
}
