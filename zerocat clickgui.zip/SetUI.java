package i.zerocat.gui.ui;

import i.zerocat.Client;
import i.zerocat.font.CFontRenderer;
import i.zerocat.font.FontLoaders;
import i.zerocat.gui.ui.category.ModuleUI;
import i.zerocat.gui.ui.setuis.*;
import i.zerocat.utils.visual.RenderUtils;
import i.zerocat.values.Value;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.util.EnumChatFormatting;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class SetUI extends GuiScreen {
    ArrayList<Value> list = new ArrayList<>();
    ModuleUI m;
    static List<PushUI> uis;
    static List<BooleanUI> buis;
    List<ModeUI> muis;
    public SetUI(List<Value> values, ModuleUI m){
        list.addAll(values);
        this.m = m;
        buis = new ArrayList<>();
        uis = new ArrayList<>();
        muis = new ArrayList<>();
        for (Value v:list){
            switch (v.info){
                case 0:
                    //numbers min max value inc
                    uis.add(new PushUI(v.getName(),v.getMin(),v.getMax(),v.getNumber()));
                    break;
                case 1:
                    //boolean
                    buis.add(new BooleanUI(v.getName(),v.getBooleanValue()));
                    break;
                case 2:
                    //mode
                    muis.add(new ModeUI(v.getName(), v.getList(),v.getMode()));
                    break;
            }
        }
    }
    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton){
        if (mouseButton != 0)
            return;
        for (PushUI b:uis){
            if (mouseX >= b.checkx[0] && mouseX<= b.checkx[1] && mouseY >=b.checky[0] && mouseY <= b.checky[1]) {
                b.hold = true;
            }
        }
        for (ModeUI b:muis){
            if (mouseX >= b.check[0] && mouseX<= b.check[1] && mouseY >=b.check[2] && mouseY <= b.check[3]) {
                for (Value v:list){
                    if (v.getName().equalsIgnoreCase(b.name))
                        v.setMode(b.click());
                }
            }
        }
        for (BooleanUI b:buis){
            if (mouseX >= b.checkx[0] && mouseX<= b.checkx[1] && mouseY >=b.checky[0] && mouseY <= b.checky[1]) {
                b.value = !b.value;
                for (Value v:list){
                    if (v.getName().equalsIgnoreCase(b.name))
                        v.setState(!v.getBooleanValue());
                }
            }
        }
    }
    @Override
    public void mouseReleased(int mouseX, int mouseY, int state){
        for (PushUI b:uis){
            if (!b.hold)
                return;
            b.hold = false;
        }
    }
    @Override
    public void mouseClickMove(int mouseX, int mouseY, int clickedMouseButton, long timeSinceLastClick){
        for (PushUI b:uis){
            if(b.hold){
                if (mouseX < b.canmove[0] || mouseX > b.canmove[1]) {
                    b.hold = false;
                    return;
                }
                if (mouseX >= b.canmove[0] && mouseX <= b.canmove[1]){
                    b.m1 = mouseX - 4;
                    b.m2 = mouseX + 4;
                    b.drawmove();
                    for (Value v:list){
                        if (v.getName().equalsIgnoreCase(b.name))
                            v.setValue(b.mathValue());
                    }
                }
            }
        }
    }
    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks)
    {
        float startX = (this.width / 3) - 20;
        float startY = (this.height / 4) - 60;
        RenderUtils.drawRoundedRect(startX,startY,startX + 205,startY + 250,0.1F,new Color(0,0,0).getRGB());
        CFontRenderer font = FontLoaders.default16;
        CFontRenderer font1 = FontLoaders.default20;
        font1.drawStringWithShadow(m.name + " >> Settings",startX + 5, startY + font.getHeight(), -1);
        Gui.drawRect((int)startX, (int)startY + font1.getStringHeight(m.name + " >> Settings") + 10,(int)startX + 204,(int)startY + font1.getStringHeight(m.name + " >> Settings") + 11,
                new Color(192,192,192).getRGB()
                );


        float y = (int)startY +FontLoaders.default20.getStringHeight(m.name + " >> Settings") + 18;
        for (ModeUI mi:muis){
            mi.draw((int) (startX + 5), (int) y);
            y += 15;
        }
        for(PushUI i:uis){
            i.draw(startX + 5,y);
            y += 15;
        }
        for(BooleanUI i:buis){
            i.draw((int)startX + 5,(int)y);
            y += 15;
        }
        font1.drawStringWithShadow((Client.instance.isDev? EnumChatFormatting.RED +"Development":EnumChatFormatting.GREEN + "User") + EnumChatFormatting.WHITE + ":" + Client.instance.user,0,this.height - font.getHeight() - 2,-1);

    }

    @Override
    public void onGuiClosed()
    {
        m.state = false;
        mc.currentScreen = new ClickGUI();
    }
}
